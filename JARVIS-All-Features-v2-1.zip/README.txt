JARVIS 2.0 - Android voice assistant

Features:
- Foreground microphone service
- Speech recognition in Hindi
- Text-to-speech
- Wake phrase response for "JARVIS"
- YouTube, Google, time, greeting commands
- Can continue running while the app is not on screen, subject to Android system rules

Important:
Android does not guarantee continuous microphone access after the OS kills a service or under battery restrictions. A foreground service with a visible notification is used intentionally.
