package com.jarvis.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class JarvisService : Service(), TextToSpeech.OnInitListener {

    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var listening = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(7, notification())
        tts = TextToSpeech(this, this)
        startListening()
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)

        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) { listening = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { listening = false }
            override fun onError(error: Int) {
                listening = false
                android.os.Handler(mainLooper).postDelayed({ startListening() }, 1200)
            }
            override fun onResults(results: android.os.Bundle?) {
                listening = false
                val text = results?.getStringArrayList(
                    SpeechRecognizer.RESULTS_RECOGNITION
                )?.firstOrNull().orEmpty()
                handle(text.lowercase(Locale.getDefault()))
                android.os.Handler(mainLooper).postDelayed({ startListening() }, 700)
            }
            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer?.startListening(intent)
    }

    private fun handle(command: String) {
        if (command.isBlank()) return

        when {
            command.contains("jarvis") || command.contains("जार्विस") -> {
                speak("Yes, Sir. मैं सुन रहा हूँ")
            }
            command.contains("youtube") || command.contains("यूट्यूब") -> {
                speak("YouTube खोल रहा हूँ")
                openUrl("https://www.youtube.com")
            }
            command.contains("google") || command.contains("गूगल") -> {
                speak("Google खोल रहा हूँ")
                openUrl("https://www.google.com")
            }
            command.contains("समय") || command.contains("time") -> {
                val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                speak("अभी समय $time है")
            }
            command.contains("नमस्ते") || command.contains("hello") -> {
                speak("नमस्ते सर, JARVIS तैयार है")
            }
            command.contains("बंद") || command.contains("stop") -> {
                speak("ठीक है सर")
                stopSelf()
            }
            else -> speak("मैंने सुना: $command")
        }
    }

    private fun openUrl(url: String) {
        val i = Intent(Intent.ACTION_VIEW).apply {
            data = android.net.Uri.parse(url)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(i)
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("hi", "IN")
            tts.setSpeechRate(0.85f)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                "jarvis_mic",
                "JARVIS Microphone",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val pending = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "jarvis_mic")
                .setContentTitle("JARVIS सक्रिय है")
                .setContentText("Voice assistant चल रहा है")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pending)
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setContentTitle("JARVIS सक्रिय है")
                .setContentText("Voice assistant चल रहा है")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pending)
                .setOngoing(true)
                .build()
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
