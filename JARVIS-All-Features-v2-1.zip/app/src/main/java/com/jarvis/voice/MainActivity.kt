package com.jarvis.voice

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<android.widget.TextView>(R.id.statusText).text =
            "JARVIS तैयार है\nपहले microphone permission दें, फिर JARVIS शुरू करें"

        findViewById<android.widget.Button>(R.id.startButton).setOnClickListener {
            requestMicAndStart()
        }

        findViewById<android.widget.Button>(R.id.stopButton).setOnClickListener {
            stopService(Intent(this, JarvisService::class.java))
        }
    }

    private fun requestMicAndStart() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }
        val intent = Intent(this, JarvisService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            requestMicAndStart()
        }
    }
}
