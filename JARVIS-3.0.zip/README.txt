JARVIS 3.0

Fixes in this version:
- No automatic start when the app is opened.
- Start only from the Start button.
- Stop actually stops the foreground service.
- START_NOT_STICKY prevents automatic service restart after termination.
- Unknown speech is ignored silently.
- No echo/repeat response.
- Commands are handled one listening session at a time.
- Foreground notification shows when microphone service is active.

Supported commands:
JARVIS / जार्विस
YouTube / यूट्यूब
Google / गूगल
समय / टाइम / time
नमस्ते / hello
बंद / बंद करो / stop / जार्विस बंद

Note: Android and the device may restrict background microphone use or kill services. This app intentionally does not force-restart itself.
