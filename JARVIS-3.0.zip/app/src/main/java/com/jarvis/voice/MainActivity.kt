package com.jarvis.voice

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    companion object {
        private const val REQ_MIC = 100
        private const val REQ_NOTIF = 101
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<android.widget.TextView>(R.id.statusText).text =
            if (JarvisService.isRunning) "चालू है" else "बंद है"

        findViewById<android.widget.Button>(R.id.startButton).setOnClickListener {
            startJarvis()
        }

        findViewById<android.widget.Button>(R.id.stopButton).setOnClickListener {
            stopService(Intent(this, JarvisService::class.java))
            findViewById<android.widget.TextView>(R.id.statusText).text = "बंद है"
        }
    }

    private fun startJarvis() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }

        ContextCompat.startForegroundService(this, Intent(this, JarvisService::class.java))
        findViewById<android.widget.TextView>(R.id.statusText).text = "चालू है"
    }
}
