package com.jarvis.voice

import android.app.*
import android.content.*
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.*

class JarvisService : Service() {
    companion object {
        @Volatile var isRunning = false
    }

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var listening = false
    private var shuttingDown = false

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        createChannel()
        startForeground(7, notification())
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
                tts?.setSpeechRate(0.9f)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!shuttingDown && !listening) {
            Handler(Looper.getMainLooper()).postDelayed({ listenOnce() }, 700)
        }
        // Do not automatically restart after the service is stopped/killed.
        return START_NOT_STICKY
    }

    private fun listenOnce() {
        if (shuttingDown || !isRunning || !SpeechRecognizer.isRecognitionAvailable(this)) return

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        listening = true

        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                listening = false
                if (!shuttingDown) {
                    // Short pause, then one new listening session. No TTS on errors.
                    Handler(Looper.getMainLooper()).postDelayed({ listenOnce() }, 900)
                }
            }

            override fun onResults(results: Bundle?) {
                listening = false
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val spoken = matches?.firstOrNull()?.lowercase(Locale.getDefault())?.trim().orEmpty()
                handleCommand(spoken)

                if (!shuttingDown) {
                    Handler(Looper.getMainLooper()).postDelayed({ listenOnce() }, 900)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "")
        }
        recognizer?.startListening(intent)
    }

    private fun handleCommand(raw: String) {
        if (raw.isBlank()) return

        // Only act on clearly recognized commands. Unknown speech is ignored.
        when {
            raw == "jarvis" || raw == "जार्विस" ||
            raw.contains("jarvis सुनो") || raw.contains("जार्विस सुनो") -> {
                speak("जी सर, मैं सुन रहा हूँ")
            }

            raw.contains("youtube") || raw.contains("यूट्यूब") -> {
                speak("यूट्यूब खोल रहा हूँ")
                openUrl("https://www.youtube.com")
            }

            raw.contains("google") || raw.contains("गूगल") -> {
                speak("गूगल खोल रहा हूँ")
                openUrl("https://www.google.com")
            }

            raw.contains("समय") || raw.contains("टाइम") || raw.contains("time") -> {
                val now = SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date())
                speak("अभी समय है $now")
            }

            raw == "नमस्ते" || raw == "hello" || raw == "हेलो" -> {
                speak("नमस्ते सर")
            }

            raw == "बंद" || raw == "बंद करो" || raw == "stop" ||
            raw == "stop jarvis" || raw == "जार्विस बंद" -> {
                speak("ठीक है सर, JARVIS बंद कर रहा हूँ")
                Handler(Looper.getMainLooper()).postDelayed({ stopSelf() }, 900)
            }

            // Everything else: stay silent.
            else -> Unit
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "JARVIS")
    }

    private fun openUrl(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (_: Exception) {}
    }

    private fun notification(): Notification {
        return NotificationCompat.Builder(this, "jarvis")
            .setContentTitle("JARVIS सक्रिय है")
            .setContentText("सिर्फ स्पष्ट कमांड पर प्रतिक्रिया देगा")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "jarvis", "JARVIS",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        shuttingDown = true
        isRunning = false
        listening = false
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
